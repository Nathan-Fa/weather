/*
 * temperature.h
 *
 *  Created on: Oct 14, 2016
 *      Author: embedded
 */

#ifndef TEMPERATURE_H_
#define TEMPERATURE_H_


#endif /* TEMPERATURE_H_ */
