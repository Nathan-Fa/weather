/*
 * utilities.h
 *
 *  Created on: Oct 14, 2016
 *      Author: embedded
 */

#ifndef UTILITIES_H_
#define UTILITIES_H_


#endif /* UTILITIES_H_ */
