#ifndef __PRESSURE180_H__
#define __PRESSURE180_H__

#include "../include/bmp180.h"

s32 BMP180Init();



#endif
